

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h4 class="card-title">Presensi</h4>
    </div>
    <div class="card-content">
        <div class="card-body">
            <div class="row">
            </div>
            <!-- Table with outer spacing -->
            <div class="table-responsive">         
                    <table class="table table-lg">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>NIP</th>
                                <th>NAMA</th>
                                <th>ROLE</th>
                                <th>TANGGAL</th>
                                <th>PRESENSI MASUK</th>
                                <th>PRESENSI KELUAR</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $x = 1;
                            ?>
                            <?php $__currentLoopData = $presences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row" style="vertical-align: middle;"><?php echo e($x); ?></td>
                                    <td class="text-bold-500"><?php echo e($presence->user->nip); ?></td>
                                    <td class="text-bold-500"><?php echo e($presence->user->name); ?></td>
                                    <td class="text-bold-500"><?php echo e($presence->user->role); ?></td>
                                    <td class="text-bold-500"><?php echo e($presence->tanggal_presensi); ?></td>
                                    <td class="text-bold-500"><?php echo e($presence->check_in_time); ?> - <?php echo e($presence->keterangan_masuk); ?></td>
                                    <td class="text-bold-500"><?php echo e($presence->check_out_time); ?> - <?php echo e($presence->keterangan_pulang); ?></td>
                                    
                                <?php
                                    $x++;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </tbody>
                    </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-presensi\resources\views/user/presence/index.blade.php ENDPATH**/ ?>