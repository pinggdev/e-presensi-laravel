

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h4 class="card-title">Keterangan</h4>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <div class="card-content">
                <div class="card-body">
                    <p>T : Terlambat</p>
                    <p>A : Alpha</p>
                    <p>H : Hadir</p>
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="card-content">
                <div class="card-body">
                    <p>TAM : Tidak Absen Masuk</p>
                    <p>TAP : Tidak Absen Pulang</p>
                    <p>P : Pulang Cepat</p>
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="card-content">
                <div class="card-body">
                    <p>TP : Terlambat dan Pulang Cepat</p>
                    <p>TAMP : Tidak Absen Masuk Pulang Cepat</p>
                    <p>TAPT : Tidak Absen Pulang dan Terlambat</p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="card">
    <div class="card-header">
        <h4 class="card-title">Data Absen Saya per Bulan</h4>
        <p><?php echo e(Auth::user()->nip); ?> - <?php echo e(Auth::user()->name); ?></p>
        <form action="/by-month-data" method="POST" class="form form-horizontal">
            <?php echo csrf_field(); ?>
            <div class="form-body">
                <div class="row">
                    <div class="col-md-6 form-group">
                        <input type="text" class="form-control" name="month" value="<?php echo e($month); ?>" placeholder="Cari Bulan...">
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary me-1 mb-1">Tambah</button>
                        <a href="/print-data-bulanan-saya/<?php echo e($month); ?>" class="btn btn-primary me-1 mb-1" target="__blank">Print</a>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="card-content">
        <div class="card-body">
            <div class="row">
            </div>
            <!-- Table with outer spacing -->
            <div class="table-responsive">         
                    <table class="table table-lg">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>TANGGAL</th>
                                <th>PRESENSI MASUK</th>
                                <th>PRESENSI KELUAR</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $x = 1;
                            ?>
                            <?php $__currentLoopData = $presences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row" style="vertical-align: middle;"><?php echo e($x); ?></td>
                                    <td class="text-bold-500"><?php echo e($presence->tanggal_presensi); ?></td>
                                    <td class="text-bold-500"><?php echo e($presence->check_in_time); ?> - <?php echo e($presence->keterangan_masuk); ?></td>
                                    <td class="text-bold-500"><?php echo e($presence->check_out_time); ?> - <?php echo e($presence->keterangan_pulang); ?></td>
                                    
                                <?php
                                    $x++;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </tbody>
                    </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-presensi\resources\views/user/presence/bymonthdata.blade.php ENDPATH**/ ?>