<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        table, td, th {
          border: 1px solid;
        }
        
        table {
          width: 100%;
          border-collapse: collapse;
        }
    </style>
</head>
<body>
    <h2>Data Absen <?php echo e(Auth::user()->name); ?></h2>
    <p>Nama : <?php echo e(Auth::user()->name); ?></p>
    <p>NIP : <?php echo e(Auth::user()->nip); ?></p>
   
        <table>
            <thead>
                <tr>
                    <th>NO</th>
                    <th>TANGGAL</th>
                    <th>PRESENSI MASUK</th>
                    <th>PRESENSI KELUAR</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $x = 1;
                ?>
                <?php $__currentLoopData = $presences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row" style="vertical-align: middle;"><?php echo e($x); ?></td>
                    <td><?php echo e($presence['tanggal_presensi']); ?></td>
                    <td><?php echo e($presence['check_in_time']); ?> - <?php echo e($presence['keterangan_masuk']); ?></td>
                    <td><?php echo e($presence['check_out_time']); ?> - <?php echo e($presence['keterangan_pulang']); ?></td>
                </tr>
                <?php $x++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tr>
            </tbody>
        </table>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\e-presensi\resources\views/user/presence/pdf/byname.blade.php ENDPATH**/ ?>