

<?php $__env->startSection('content'); ?>
    <?php if($distance >= $max_distance): ?>
        <div class="card-body">
            <div class="alert alert-danger">Berada di luar jangkauan, tidak bisa absen</div>
        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Aturan</h4>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="card-content">
                    <div class="card-body">
                        <p>Pagi : dimulai pukul 04.00 WIB - 07.00 WIB (senin - Jum'at)</p>
                        <p>Sore : dimulai pukul 15.30 WIB - 22.30 WIB (senin - Kamis)</p>
                        <p>Sore : dimulai pukul 14.00 WIB - 21.00 WIB (Jum'at)</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Absen Masuk</h4>
        </div>
        <div class="card-content">
            <div class="card-body">
                <form action="<?php echo e(route('presences.store')); ?>" method="POST" class="form form-horizontal">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <div class="row">
                            <input name="user_id" type="hidden" value="<?php echo e(Auth::user()->id); ?>">
                            <div class="col-md-4">
                                <label>Jam Masuk</label>
                            </div>
                            <div class="col-md-8 form-group">
                                <input type="time" class="form-control" name="" value=<?php if($checkIn): ?>
                                <?php echo e($checkIn->check_in_time); ?>

                                <?php else: ?>
                                <?php echo e(now()->format('H:i')); ?>

                                <?php endif; ?> disabled>
                            </div>
                            <input type="hidden" class="form-control" name="check_in_time" value="<?php echo e(now()->format('H:i')); ?>">
                            <div class="col-md-4">
                                <label>Keterangan Masuk</label>
                            </div>
                            <fieldset class=" col-md-8 form-group">
                                <select class="form-select <?php $__errorArgs = ['keterangan_masuk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basicSelect" name="keterangan_masuk" <?php if($distance >= $max_distance || $checkIn): ?>
                                    <?php echo e("disabled"); ?>

                                <?php endif; ?>>
                                    <option value="">Pilih...</option>    
                                    <option value="t" <?php if($keteranganMasuk === "t"): ?>
                                        selected
                                    <?php endif; ?>>Terlambat</option> 
                                    <option value="a" <?php if($keteranganMasuk === "a"): ?>
                                        selected
                                    <?php endif; ?>>Alpha</option> 
                                    <option value="h" <?php if($keteranganMasuk === "h"): ?>
                                        selected
                                    <?php endif; ?>>Hadir</option> 
                                    <option value="tam" <?php if($keteranganMasuk === "tam"): ?>
                                        selected
                                    <?php endif; ?>>Tidak Absen Masuk</option> 
                                    <option value="tap" <?php if($keteranganMasuk === "tap"): ?>
                                        selected
                                    <?php endif; ?>>Tidak Absen Pulang</option> 
                                    <option value="p" <?php if($keteranganMasuk === "p"): ?>
                                        selected
                                    <?php endif; ?>>Pulang Cepat</option> 
                                    <option value="tp" <?php if($keteranganMasuk === "tp"): ?>
                                        selected
                                    <?php endif; ?>>Terlambat dan Pulang Cepat</option> 
                                    <option value="tamp" <?php if($keteranganMasuk === "tamp"): ?>
                                        selected
                                    <?php endif; ?>>Tidak Absen Masuk dan Pulang Cepat</option> 
                                    <option value="tapt" <?php if($keteranganMasuk === "tapt"): ?>
                                        selected
                                    <?php endif; ?>>Tidak Absen Pulang dan Terlambat</option> 
                                </select>
                                <?php $__errorArgs = ['keterangan_masuk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </fieldset>
                            <div class="col-sm-12 d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary me-1 mb-1" 
                                <?php if($distance >= $max_distance || $checkIn): ?>
                                    <?php echo e("disabled"); ?>

                                <?php endif; ?>>Tambah</button>
                                <?php if(!$checkIn): ?>
                                    <a href="/" class="btn btn-light-secondary me-1 mb-1">Batal</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php if($checkIn): ?>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Absen Pulang</h4>
        </div>
        <div class="card-content">
            <div class="card-body">
                <form action="<?php echo e(route('presences.update', $checkIn->id)); ?>" method="POST" class="form form-horizontal">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="form-body">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Jam Pulang</label>
                            </div>
                            <div class="col-md-8 form-group">
                                <input type="time" class="form-control" name="" value=<?php if($checkOut): ?>
                                <?php echo e($checkOut->check_out_time); ?>

                                <?php else: ?>
                                <?php echo e(now()->format('H:i')); ?>

                                <?php endif; ?> disabled>
                            </div>
                            <input type="hidden" class="form-control" name="check_out_time" value="<?php echo e(now()->format('H:i')); ?>">
                            <div class="col-md-4">
                                <label>Keterangan Pulang</label>
                            </div>
                            <fieldset class=" col-md-8 form-group">
                                <select class="form-select <?php $__errorArgs = ['keterangan_pulang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basicSelect" name="keterangan_pulang" <?php if($distance >= $max_distance || $checkOut): ?>
                                    <?php echo e("disabled"); ?>

                                <?php endif; ?>>
                                    <option value="">Pilih...</option>    
                                    <option value="t" <?php if($keteranganPulang === "t"): ?>
                                    selected
                                <?php endif; ?>>Terlambat</option> 
                                    <option value="a" <?php if($keteranganPulang === "a"): ?>
                                    selected
                                <?php endif; ?>>Alpha</option> 
                                    <option value="h" <?php if($keteranganPulang === "h"): ?>
                                    selected
                                <?php endif; ?>>Hadir</option> 
                                    <option value="tam" <?php if($keteranganPulang === "tam"): ?>
                                    selected
                                <?php endif; ?>>Tidak Absen Masuk</option> 
                                    <option value="tap" <?php if($keteranganPulang === "tap"): ?>
                                    selected
                                <?php endif; ?>>Tidak Absen Pulang</option> 
                                    <option value="p" <?php if($keteranganPulang === "p"): ?>
                                        selected
                                    <?php endif; ?>>Pulang Cepat</option> 
                                    <option value="tp" <?php if($keteranganPulang === "tp"): ?>
                                    selected
                                <?php endif; ?>>Terlambat dan Pulang Cepat</option> 
                                    <option value="tamp" <?php if($keteranganPulang === "tamp"): ?>
                                    selected
                                <?php endif; ?>>Tidak Absen Masuk dan Pulang Cepat</option> 
                                    <option value="tapt" <?php if($keteranganPulang === "tapt"): ?>
                                    selected
                                <?php endif; ?>>Tidak Absen Pulang dan Terlambat</option> 
                                </select>
                                <?php $__errorArgs = ['keterangan_pulang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </fieldset>
                            <div class="col-sm-12 d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary me-1 mb-1" 
                                <?php if($distance >= $max_distance || $checkOut): ?>
                                    <?php echo e("disabled"); ?>

                                <?php endif; ?>>Tambah</button>
                                <?php if(!$checkOut): ?>
                                    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-light-secondary me-1 mb-1">Batal</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-presensi\resources\views/user/presence/form.blade.php ENDPATH**/ ?>